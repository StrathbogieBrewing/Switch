The following Gerber files are included:

theswitch.GBL - Bottom Layer Copper
theswitch.GBO - Bottom Layer Silk Screen Overlay
theswitch.GBS - Bottom Layer Solder Mask
theswitch.GM1 - Mechanical Outline of Board
theswitch.GTL - Top Layer Copper
theswitch.GTO - Top Layer Silk Screen Overlay
theswitch.GTS - Top Layer Solder Mask
theswitch.TXT - NC Drill File

The Gerber format is 4:4 Metric.

We require double sided 1.6mm FR4 Printed Circuit Board Panel with 35 um copper plating and plated through holes.
We require top and bottom solder mask to be green in colour.
We require top and bottom overlay to be white in colour.
Hole sizes in NC drill file are finished hole sizes, please adjust to suit your production system.
